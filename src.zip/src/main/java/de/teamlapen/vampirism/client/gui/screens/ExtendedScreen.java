package de.teamlapen.vampirism.client.gui.screens;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.api.EnvironmentInterface;

import de.teamlapen.vampirism.inventory.TaskMenu;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

/**
 * instead of mixin/coremod/AT let screens extend this to access certain attributes
 */
@Environment(EnvType.CLIENT)
public interface ExtendedScreen {

    /**
     * @return {@link de.teamlapen.vampirism.inventory.TaskMenu} of the screen
     */
    TaskMenu getTaskContainer();
}
