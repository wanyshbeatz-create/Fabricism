package de.teamlapen.vampirism.blockentity;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.api.EnvironmentInterface;

import de.teamlapen.vampirism.blocks.CoffinBlock;
import de.teamlapen.vampirism.core.ModSounds;
import de.teamlapen.vampirism.core.ModTiles;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.Connection;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 * TileEntity for coffins. Handles coffin lid position and color
 */
public class CoffinBlockEntity extends BlockEntity {
    public float lidPos;
    public DyeColor color = DyeColor.RED;
    private boolean playLidSoundFlag;

    public CoffinBlockEntity(@NotNull BlockPos pos, @NotNull BlockState state) {
        super(ModTiles.COFFIN.get(), pos, state);
    }

    public CoffinBlockEntity(@NotNull BlockPos pos, @NotNull BlockState state, DyeColor color) {
        super(ModTiles.COFFIN.get(), pos, state);
        this.color = color;
    }

    public void changeColor(DyeColor color) {
        this.color = color;
        setChanged();
    }

    @Override
    public @NotNull AABB getRenderBoundingBox() {
        return new AABB(worldPosition.getX() - 4, worldPosition.getY(), worldPosition.getZ() - 4, worldPosition.getX() + 4, worldPosition.getY() + 2, worldPosition.getZ() + 4);
    }

    @Nullable
    @Override
    public ClientboundBlockEntityDataPacket getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }

    @NotNull
    @Override
    public CompoundTag getUpdateTag() {
        return this.saveWithoutMetadata();
    }

    @Override
    public void load(@NotNull CompoundTag compound) {
        super.load(compound);
        this.color = compound.contains("color") ? DyeColor.byId(compound.getInt("color")) : DyeColor.BLACK;
        this.lidPos = compound.getFloat("lidPos");
    }

    @Environment(EnvType.CLIENT)
    @Override
    public void onDataPacket(Connection net, @NotNull ClientboundBlockEntityDataPacket packet) {
        if (hasLevel()) load(packet.getTag());
    }

    @Override
    public void saveAdditional(@NotNull CompoundTag compound) {
        super.saveAdditional(compound);
        compound.putInt("color", this.color.getId());
        compound.putFloat("lidPos", this.lidPos);
    }

    @Override
    public void setChanged() {
        super.setChanged();
        if (level != null) {
            level.sendBlockUpdated(getBlockPos(), level.getBlockState(worldPosition), level.getBlockState(worldPosition), 3);
        }
    }

    public static void clientTickHead(@NotNull Level level, @NotNull BlockPos pos, BlockState state, @NotNull CoffinBlockEntity blockEntity) {
        boolean occupied = CoffinBlock.isClosed(level, pos);
        if (blockEntity.playLidSoundFlag != occupied) {
            level.playLocalSound(pos.getX(), (double) pos.getY() + 0.5D, pos.getZ(), ModSounds.COFFIN_LID.get(), SoundSource.BLOCKS, 0.5F, level.random.nextFloat() * 0.1F + 0.9F, true);
            blockEntity.playLidSoundFlag = CoffinBlock.isClosed(level, pos);
        }

        // Calculate lid position
        boolean isClosed = blockEntity.hasLevel() && CoffinBlock.isClosed(level, pos);
        if (!isClosed) {
            blockEntity.lidPos += 0.02;
        } else {
            blockEntity.lidPos -= 0.02;
        }
        blockEntity.lidPos = Mth.clamp(blockEntity.lidPos, 0, 1);

    }
}